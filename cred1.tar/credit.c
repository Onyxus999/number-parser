#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cs50.h>
#include "numParse.h"

/***
 ***	This program takes a credit card number from the user and 
 ***	tests to see if it is valid. If it is, the program will
 ***	output the type of credit card. If it isn't, the program
 ***	will output "INVALID"
 ***
 ***	Author: Onyxus999 (Jacob Rogers)				*/

int main(void)
{
	
	long credit_number;
	int length_ccnumber, index_of_prodlst, length_proddigs, index_of_proddigs, total_sum, length_total_sum;

	printf("Enter the credit card number to test: ");
	
	// Get the number to test from the user
	// Get that numbers length and an array of its digits 
	// (see ./include/numParse.h for function declaration
	//  and see ./lib/source/numParse.c for function definition)
	credit_number = GetLongLong();
	length_ccnumber = count_dig(credit_number);
	int* list_of_digits = digitize(credit_number);

	// Create an array half the size of the length of the CC number
	// starting from the second to last digit, multiply every other
	// digit by two and add it to that array.
	int* list_of_products = malloc( sizeof(int) * ( length_ccnumber / 2 ) );
	index_of_prodlst = 0;
	for (int i = length_ccnumber-2; i >= 0; i -= 2)
	{
		list_of_products[index_of_prodlst] = (list_of_digits[i] * 2);
		index_of_prodlst++; 
	}

	// Find the total number of digits in all of the products
	// calculated above.
	length_proddigs = 0;
	for (int i = 0; i < (length_ccnumber / 2); i++)
	{
		length_proddigs += count_dig(list_of_products[i]);
	}

	// Make an array the size of the number of total digits
	// calculated above. Add every digit from the products
	// to that array by looping through every product in the
	// product list and then looping through every digit for
	// each one of those products
	int* list_of_proddig = malloc( sizeof(int) * length_proddigs );
	index_of_proddigs = 0;
	for (int i = 0; i < (length_ccnumber / 2); i++)
	{
		for (int j = 0; j < count_dig(list_of_products[i]); j++)
		{
			list_of_proddig[index_of_proddigs] = digital(list_of_products[i], j);
			index_of_proddigs++;
		}
	}

	// Calculate the total sum of the digits of the product list
	// by looping through the product digit list.
	total_sum = 0;
	for (int i = 0; i < length_proddigs; i++)
	{
		total_sum += list_of_proddig[i];
	}

	// If the last digit of the total sum is 0, the CC number
	// is valid. Otherwise, it is not.
	length_total_sum = count_dig(total_sum);
	if ( digital(total_sum, length_total_sum - 1) == 0 )
	{
		// If the CC Number is valid,
		// the first digit is 4, and
		// it has 16 digits, it is a
		// VISA.
		if (digital(credit_number, 1) == 4 /*&& length_ccnumber == 16*/)
		{
			printf("VISA\n");
		}

		// If the CC Number is valid,
		// the first digit is 5, and
		// it has 16 digits, it is a
		// AMEX.
		else if (digital(credit_number, 1) == 3 /*&& length_ccnumber == 16*/)
		{
			printf("AMEX\n");
		}
		
		// If the CC Number is valid,
		// the first digit is anything
		// and it has 15 digits, it is a
		// MASTERCARD.
		else if (digital(credit_number, 1) == 5 /*&& length_ccnumber == 15*/)
		{
			printf("MASTERCARD");
		}

		// If the CC Number is valid,
		// the first digit is anything,
		// and it has any number of digits,
		// it is an other form of CC.
		else
		{
			printf("OTHER\n");
		}
		printf("%d\n", digital(credit_number, 1));		
	}
	else
	{

		// If the CC Number is invalid
		// it is an INVALID.
		printf("INVALID\n");
	}
	
	// Free the memory for all the arrays
	free(list_of_digits);
	free(list_of_products);
	free(list_of_proddig);

	return 0;
}
