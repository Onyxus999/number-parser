#include <stdlib.h>
#include <stdio.h>
#include <math.h>
/***									***
 ***	This module defines functions to handle parsing of numbers	***
 ***		into strings and strings of digits. 			***
 ***									***
 ***	Author: Onyxus999 (Jacob Rogers)				***/

/*
 *	This function takes an long and returns the number of digits
 */
long count_dig(long num)
{
//	printf("\tNum: %ld\n", num);
//	return sizeof(num);		
	long up_bound = 10;
	long num_digits = 1;

	while (1==1)
	{
		// If the number is smaller than the upper bound, return the number of digits
		if (num < up_bound) {
			return num_digits;
		}
		// If the number is greater than the upper bound, raise the upper bound by a factor of 10 and add 1 to the number of digits
		// (So e.g. 32 > 10 -> up_bound = 100, num_digits = 2 -> 32 < 100 -> return num_digits)
		else {
			up_bound *= 10;
			num_digits++;
		}
	}

}

/*
 *	This function takes an long and teturns the ith digit of it
 */
int digital(long num, int i)
{
	// This will make the indexing start from the left, 
	// rather then the right
	int index = count_dig(num) - i;
	return ((num % (long) pow(10, index)) / pow(10, index-1));
}

/*
 *	This function takes an long and returns the ith digit as a char
 */
char charital(long num, int i)
{
	char char_dig;
	sprintf(&char_dig, "%d", digital(num, i));
	return char_dig;
}

/*
 *	This function takes an long and returns a c-string of its digits.	
 */
char* charitize(long num)
{

	char* str_digits = malloc(sizeof(int) * count_dig(num));

	for (int i = 0; i < count_dig(num); i++)
	{
		str_digits[i] = charital(num, i);				
	}

	return str_digits;

}

/*
 *	This function takes an long and returns a pointer to an array of its digits.
 */
int* digitize(long num)
{

	int* lst_digits = malloc(sizeof(int) * count_dig(num));

	for (int i = 0; i < count_dig(num); i++)
	{
		lst_digits[i] = digital(num, i);
	}

	return lst_digits;

}

